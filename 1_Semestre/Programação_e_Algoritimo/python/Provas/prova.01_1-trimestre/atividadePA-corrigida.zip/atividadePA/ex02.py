for umacem in range(1,100):
    imparpar = umacem % 2
    if imparpar == 0:
        print('*')
    else:
        print('**')