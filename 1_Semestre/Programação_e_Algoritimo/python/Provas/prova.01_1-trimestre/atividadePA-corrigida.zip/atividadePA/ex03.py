for umacem in range(1,101):
    mult4 = umacem % 4
    if mult4 == 0:
        print('PI')
    else:
        print(umacem)