saida = ''
for cont in range(1,10):
    saida += '*'
    print (saida)