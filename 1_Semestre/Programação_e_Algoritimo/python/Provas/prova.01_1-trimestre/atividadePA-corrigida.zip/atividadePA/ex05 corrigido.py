acum = ''
for i in range (1,3):
    for cont in range(1,10):
        acum += '*'
        print (acum)
    acum = ''