for tri in range(1,5):
    for ast in range (1,5):
        print('*' * ast)