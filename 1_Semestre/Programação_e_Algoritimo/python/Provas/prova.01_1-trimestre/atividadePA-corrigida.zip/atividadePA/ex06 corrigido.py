acumulador = ''
for linha in range(1, 6, 1):
    for cont in range(1,6, 1):
        acumulador += '*'
    print(acumulador)
    acumulador = ''