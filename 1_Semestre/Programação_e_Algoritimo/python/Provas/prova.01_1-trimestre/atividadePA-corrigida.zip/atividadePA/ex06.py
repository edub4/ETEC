for quad in range(1,6):
    quadrado = '*****'
    print(quadrado)