print('''
1 - Imprimir os números de 1 até 100.

2 - Imprimir os números de 1 até 100 com um "*" números ímpares e dois “**” para números pares.

3 - Imprimir os números de 1 até 100. Para os números múltiplos de 4, imprimir a palavra “PI”.

4 - Imprimir um triângulo de “*”.

5 - Imprimir vários triângulos de “*”.

6 - Imprimir um quadrado perfeito.

7 - Sair
 ''')

continuar = True
while continuar == True:
    escolha = int(input('DIGITE O NUMERO DA REPETIÇÃO QUE DESEJA EXECUTAR: '))
    if escolha == 1:
        for numeros in range(1, 101):
            print(numeros)

    elif escolha == 2:
        for umacem in range(1, 100):
            imparpar = umacem % 2
            if imparpar == 0:
                print('*')
            else:
                print('**')

    elif escolha == 3:
        for umacem in range(1, 101):
            mult4 = umacem % 4
            if mult4 == 0:
                print('PI')
            else:
                print(umacem)

    elif escolha == 4:
        saida = ''
        for cont in range(1, 10):
            saida += '*'
            print(saida)
    elif escolha == 5:
        acum = ''
        for i in range(1, 3):
            for cont in range(1, 10):
                acum += '*'
                print(acum)
            acum = ''
    elif escolha == 6:
        acumulador = ''
        for linha in range(1, 6, 1):
            for cont in range(1, 6, 1):
                acumulador += '*'
            print(acumulador)
            acumulador = ''
    elif escolha == 7:
        continuar = False
    else:
        print('opção invalida')